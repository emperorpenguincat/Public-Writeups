from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/victory', methods=['POST'])
def submit_score():
    data = request.get_json()
    score = data.get('score', 0)
    if score >= 7:
        return jsonify({"message": "ICTF25{0e9ce052105ac660739950879a243734615e41baca30fa2892646f3bc9307c8e}"})
    else:
        return jsonify({"message": "Not enough for flag"})

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=8080,debug=True)
