from flask import Flask, render_template, request, jsonify
import subprocess
import os
import uuid
import base64
import time
import shutil

app = Flask(__name__)
app.config['SECRET_KEY'] = '61826684b2a186901c3bbdd6eadc0465'
app.config['TEMP_FOLDER'] = 'temp'
app.config['FLAG'] = 'ICTF25{dd265d58e3e1941a0cce646df439ea13c931d0159fe5c754cd39c8bad146fea7}'

os.makedirs(app.config['TEMP_FOLDER'], exist_ok=True)

LATEX_TEMPLATE = r"""
\documentclass{{article}}
\usepackage{{amsmath}}
\pagestyle{{empty}}

\begin{{document}}
{}
\end{{document}}
"""

blacklisted = ['flag', '.txt','newread','openin','read','file','line','closein','verbatim','usepackage','verbatiminput','lstinputlisting']

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/render', methods=['POST'])
def render_latex():
    cleanup_old_jobs(app.config['TEMP_FOLDER'])

    latex_code = request.form.get('latex', '')

    for word in blacklisted:
        if word in latex_code.lower():
            return jsonify({'error': 'Forbidden word detected'})

    job_id = str(uuid.uuid4())
    job_dir = os.path.join(app.config['TEMP_FOLDER'], job_id)
    os.makedirs(job_dir, exist_ok=True)

    try:
        flag_path = os.path.join(job_dir, 'flag.txt')
        with open(flag_path, 'w') as f:
            f.write(app.config['FLAG'])  

        full_latex = LATEX_TEMPLATE.format(latex_code)
        tex_file = os.path.join(job_dir, 'document.tex')
        with open(tex_file, 'w') as f:
            f.write(full_latex)

        result = subprocess.run(
            ['pdflatex', '-interaction=nonstopmode', '-output-directory', job_dir, tex_file],
            timeout=5,
            capture_output=True,
            text=True
        )

        if result.returncode != 0:
            return jsonify({
                'error': 'Invalid Function!'
            })

        pdf_file = os.path.join(job_dir, 'document.pdf')
        png_file = os.path.join(job_dir, 'output.png')
        convert_result = subprocess.run(
            ['convert', '-density', '150', pdf_file, '-quality', '90', png_file],
            timeout=5,
            capture_output=True,
            text=True
        )

        if convert_result.returncode != 0:
            return jsonify({'error': 'Image conversion failed'})

        with open(png_file, 'rb') as f:
            image_data = base64.b64encode(f.read()).decode('utf-8')

        response = {'image': image_data}
        return jsonify(response)

    except subprocess.TimeoutExpired:
        return jsonify({'error': 'Compilation Timed Out'})
    except Exception as e:
        return jsonify({'error': 'An error occurred'})
    finally:
        pass


def cleanup_old_jobs(temp_folder, max_age_seconds=60): 
    now = time.time()
    for job_name in os.listdir(temp_folder):
        job_path = os.path.join(temp_folder, job_name)
        if os.path.isdir(job_path):
            try:
                creation_time = os.path.getctime(job_path)
                if now - creation_time > max_age_seconds:
                    shutil.rmtree(job_path)
            except Exception as e:
                print(f"Cleanup error for {job_path}: {e}")


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
