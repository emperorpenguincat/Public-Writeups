from flask import Flask, jsonify, request, make_response, send_from_directory, render_template
from flask_cors import CORS
import secrets
import os

app = Flask(__name__)
CORS(app, supports_credentials=True)

STATIC_FOLDER = os.path.join(os.getcwd(), 'static')
app.config['STATIC_FOLDER'] = STATIC_FOLDER

players = {}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/start', methods=['POST'])
def start_game_session():
    token = secrets.token_hex(16)
    players[token] = {'score': 0}
    response = make_response(jsonify({'token': token}))
    response.set_cookie('player_token', token, httponly=True, samesite='Lax') 
    return response

@app.route('/update_score', methods=['POST'])
def update_score():
    token = request.cookies.get('player_token') or request.json.get('token')
    if not token or token not in players:
        return jsonify({'message': 'Invalid session or token'}), 400

    action = request.json.get('action')
    if action == 'increment_score':
        players[token]['score'] += 1

    elif action == 'boss_defeated':
        players[token]['score'] += 10
    score = players[token]['score']

    if score == 5:
        return jsonify({'message': "First Boss! Alcyone has arrived!", 'boss':"boss1"})
    
    if score == 20:
        return jsonify({'message': "Second Boss! Maia has arrived!", 'boss':"boss2"})
    
    if score == 35:
        return jsonify({'message': "Third Boss! Celaeno has arrived!", 'boss':"boss3"})
    
    if score == 50:
        return jsonify({'message': "Forth Boss! Electra has arrived!", 'boss':"boss4"})
    
    if score == 65:
        return jsonify({'message': "Fifth Boss! Merope has arrived!", 'boss':"boss5"})
    
    if score == 80:
        return jsonify({'message': "Sixth Boss! Asterope has arrived!", 'boss':"boss6"})
    
    if score == 95:
        return jsonify({'message': "Final Boss! Taygete has arrived!", 'boss':"boss7"})
    
    if score == 105:
        players[token]['won'] = True
        return jsonify({'flag': True})

@app.route('/flag')
def flag():
    token = request.cookies.get('player_token')
    if token in players and players[token].get('won'):
        return render_template('flag.html')
    return "Forbidden", 403

@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory(app.config['STATIC_FOLDER'], filename)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
