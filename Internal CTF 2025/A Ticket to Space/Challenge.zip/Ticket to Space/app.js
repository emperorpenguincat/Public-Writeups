const express = require("express");
const jwt = require("jsonwebtoken");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const host = '0.0.0.0';
const app = express();
const port = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));
app.use("/private", (req, res) => res.sendStatus(403));


if (!fs.existsSync('private.pem') || !fs.existsSync('public.pem')) {
  const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', {
    modulusLength: 2048,
    publicKeyEncoding: { type: 'spki', format: 'pem' },
    privateKeyEncoding: { type: 'pkcs8', format: 'pem' }
  });
  fs.writeFileSync('private.pem', privateKey);
  fs.writeFileSync('public.pem', publicKey);
  console.log("Generated new RSA key pair");
}

const flagFilePath = path.join(__dirname, "private", "flag.html");
const privateKeyPath = path.join(__dirname, "private.pem");
const publicKeyPath = path.join(__dirname, "public.pem");
const privateKey = fs.readFileSync(privateKeyPath, "utf8");
const publicKey = fs.readFileSync(publicKeyPath, "utf8");

app.get("/genToken", (req, res) => {
  const token = jwt.sign({ 
    purchasePerm: false, 
    exp: Math.floor(Date.now() / 1000) + 3600 
  }, 
  privateKey, 
  { 
    algorithm: 'RS256' 
  });
  res.json({ token });
});

const getVerificationKey = (header, callback) => {
  try {
    if (header.alg === 'HS256') {
      const hmacSecret = publicKey
        .replace('-----BEGIN PUBLIC KEY-----', '')
        .replace('-----END PUBLIC KEY-----', '')
        .replace(/\n/g, '')
        .trim();
      
      callback(null, Buffer.from(hmacSecret, 'base64'));
    } else {
      callback(null, publicKey);
    }
  } catch (err) {
    console.error("Error getting verification key:", err);
    callback(err);
  }
};

const verifyToken = (req, res, next) => {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ message: "Authorization header required with Bearer token" });
  }
  
  const token = authHeader.split(" ")[1];
  
  try {
    const parts = token.split('.');
    const header = JSON.parse(Buffer.from(parts[0], 'base64url').toString());
  } catch (err) {
    console.error("Error parsing token:", err);
  }
  
  jwt.verify(token, getVerificationKey, { 
    algorithms: ['RS256', 'HS256'],
  }, (err, decoded) => {
    if (err) {
      console.error("Token verification error:", err.message);
      return res.status(401).json({ message: "Token Verification Failure" });
    }
    
    req.user = decoded;
    next();
  });
};

app.get("/buyTicket", verifyToken, (req, res) => {
  if (req.user.purchasePerm !== true) {
    return res.status(403).json({ message: "Not your turn yet! Please Wait!" });
  }
  
  res.sendFile(flagFilePath, (err) => {
    if (err) {
      console.error("Error sending flag.html:", err);
      res.status(500).send("Error sending the flag file");
    }
  });
});


app.listen(port, host, () => {
  console.log(`Server is running on port ${port}`);
});